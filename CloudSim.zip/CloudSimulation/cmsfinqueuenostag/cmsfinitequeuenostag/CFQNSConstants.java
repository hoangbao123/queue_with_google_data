package cmsfinitequeuenostag;

/**
 * Created by dangbk on 15/04/2015.
 */
public class CFQNSConstants {  // giong het CFQSConstants

    public static final int ON = 501;
    public static final int OFF = 502;
    public static final int MIDDLE = 503;
    public static final int SetupMode = 504;
    public static final int TurnONSuccess = 505;
    public static final int MiddleSucess = 506;
    public static final int ControlMiddleHostEvent = 507;
    public static final int sendCloudletEvent = 508;
    public static final int JobComplete = 509;
    public static final int InitSubsystemSuccess = 510;
    public static final int ReleaseBufferOfBroker = 511;
    public static final int ProcessJobLeave = 512;
    public static final int ChangeLambda = 513;
    public static final int ChangeMuy = 514;

}
