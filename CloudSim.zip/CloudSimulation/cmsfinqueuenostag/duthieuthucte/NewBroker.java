package duthieuthucte;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;

import cmsfinitequeuenostag.CFQNSBroker;
import cmsfinitequeuenostag.CFQNSConstants;
import cmsfinitequeuenostag.CFQNSHelper;
import cmsfinitequeuenostag.CFQNSJob;
import controlmidleserverstag.StdRandom;

public class NewBroker extends CFQNSBroker {
	protected File file ;
	protected Scanner input;
	protected List<NewCloudlet> receivedCLoudletList ;
	//protected long numberOfJob = 0;
	protected int job = 0;
	
	
	public NewBroker(String name, double _lamda) throws Exception {
		super(name, _lamda);
	 //   file = new File("./outputdata/11_9_2017_dulieuthucte_comiddle_1.csv");
	    //file = new File("./outputdata/data_17_8_2017_da_toi_uu.csv");
		 file = new File("./outputdata/data_13_10_2017.csv");
	    try{
	    	input = new Scanner(file);
	    	input.nextLine();
	    }catch(Exception e){
	    	e.printStackTrace();
	    	
	    }
	    receivedCLoudletList = new ArrayList<NewCloudlet>();
		
	}
	protected  void submitCloudlets() {
//      Log.printLine("broker send the cloudlet first");
      sendCloudlet();

      // kich hoat datacenter hoat dong ( bat lien tiep may
      // voi thuat toan control middle servers
      // ham nay chi duoc goi mot lan sau khi broker duoc khoi tao va cloudsim.startsimulation()
      sendNow(CFQNSHelper.getMainDatacenterId(), CFQNSConstants.ControlMiddleHostEvent, new Integer(0));

  }
	public void sendCloudlet(){
		
		
	//	int queueid = selectDatacenterForSingleQueue();
		if(input.hasNext()){
			
			NewCloudlet cl = readCloudletFromFile();
			double delay = cl .submitTime-CloudSim.clock();
			send(NewHelper.getMainDatacenterId(), delay, CloudSimTags.CLOUDLET_SUBMIT, cl);
			send(getId(),0,CFQNSConstants.sendCloudletEvent);
			
//			if(cl.submitTime >= CloudSim.clock() && cl.submitTime <= CloudSim.clock()+200){ //neu submit time <= 
//				
//				se/ndNow(CFQNSHelper.getMainDatacenterId(), CloudSimTags.CLOUDLET_SUBMIT, cl);
//	            send(getId(),0, CFQNSConstants.sendCloudletEvent);//gui lai event cho broker de thuc hien lai ham cloudlet submit
//	           // System.out.println("1"+cl.toString());
//			}else{
//				//System.out.println("2"+cl.toString());
//				//
//				
//				send(CFQNSHelper.getMainDatacenterId(),delay, CloudSimTags.CLOUDLET_SUBMIT, cl);
//	            send(getId(),0, CFQNSConstants.sendCloudletEvent);
			
		}
				
//		}-------------------------------------------
//		NewCloudlet cl = NewHelper.createJob(getId());
//		cl.setSubmitTime(CloudSim.clock());
//		sendNow(NewHelper.getMainDatacenterId(), CloudSimTags.CLOUDLET_SUBMIT, cl);
//		send(getId(), StdRandom.exp(lamda), CFQNSConstants.sendCloudletEvent);
	}
	public NewCloudlet readCloudletFromFile(){
		
		
		String data = input.nextLine();
		String[] values = data.split(",");
		double submitTime = Double.parseDouble(values[0])/1000000;
		double executionTime = (Double.parseDouble(values[2])-Double.parseDouble(values[1]))/1000000 ; 
//		double submitTime = Double.parseDouble(values[1]);
//		double executionTime = (Double.parseDouble(values[2]));
		//System.out.println("exe"+executionTime);
		long id = Long.parseLong(values[3]);
		NewCloudlet  cl = (NewCloudlet)NewHelper.createJob(getId());
		cl.setSubmitTime(submitTime);
		cl.setExecutionTime(executionTime);
		cl.setId(id);
		//System.out.println(cl.toString());
		//cl.setFinishTime(3300);
		//System.out.println("***********"+cl.getExecutionTime());
		
		
		return cl;
		
	}
	public void processCloudletReturn(SimEvent ev){
		NewCloudlet cl = (NewCloudlet) ev.getData();
		if (cl.getFinishTime()== 0) {
        //  System.out.println("*********  job chua hoan thanh duoc tra lai broker");
           return;
       }
		numberofjob++;
		//cl.setFinishTime(CloudSim.clock());
		//System.out.println("broker"+cl.toString());
	//	System.out.println("cloudsim clock"+CloudSim.clock());
		receivedCLoudletList.add(cl);
		if(start){
			
			if (CloudSim.clock() > NewHelper.totalTimeSimulate) {
				System.out.println("false");
				start=false;
				
	            Log.printLine(CloudSim.clock());
	            CloudSim.terminateSimulation();
	        }
			//if(cl.getTimeStartExe()!=0){
				job++;
				//System.out.println("cl start time:"+cl.getTimeStartExe());
				totalwaitingTime =totalwaitingTime- cl.submitTime + cl.getTimeStartExe();
				totalResponseTime = totalResponseTime+cl.finishTime-cl.submitTime;
			//}
		}else{
			 if (CloudSim.clock() > CFQNSHelper.timeStartSimulate) {
	                start = true;
	                //System.out.println("bat dau dem so job");
	            }
		}
		
		
	}
	public List<NewCloudlet> getReceivedCloudletList(){
		return receivedCLoudletList;
	}
	public double getMeanWaittingTime() {
	        return totalwaitingTime / (job);
	    }

	public double getMeanResponseTime() {
	        return totalResponseTime / job;
	}
//	public static void main(String args[]){
//		try {
//			NewBroker br = new NewBroker("mot", 8);
//			while(br.input.hasNext()){
//				br.receivedCLoudletList.add(br.readCloudletFromFile());
//			}
//			int s = br.receivedCLoudletList.size();
//			String indent = "      ";
//			System.out.println("ID"+indent+"submittime"+indent+"execution time"+indent+"finish time");
//			for(NewCloudlet a : br.receivedCLoudletList){
//				System.out.println(a.id+indent+a.submitTime+indent+a.getExecutionTime()+indent
//						+a.finishTime);
//			}
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	
//	}
}
