package duthieuthucte;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ConfigureFile {
	File fl;
	FileWriter fw;
	Scanner input ;

	public ConfigureFile(){
		fl  = new File("./outputdata/data_17_8_2017_da_toi_uu.csv");
		try{
			input = new Scanner(fl);
			fw = new FileWriter("./outputdata/data_13_10_2017.csv");
		}catch(FileNotFoundException e){
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void readFromFile(){
		String values[];
		while(input.hasNextLine()){
			values = input.nextLine().split(",");
			//double submitTime = Double.parseDouble(values[0]);
			double executionTime = Double.parseDouble(values[2])/1000000-Double.parseDouble(values[1])/1000000;
			//long id = Long.parseLong(values[3]);
			if(executionTime<8000){
				try {
					fw.write(values[0]+",");
					fw.write(values[1]+",");
					fw.write(values[2]+",");
					fw.write(values[3]+"\n");
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		}
		System.out.println("done");
	}
	public static void main(String args[]){
		new ConfigureFile().readFromFile();
	}
}
