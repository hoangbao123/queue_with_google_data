package duthieuthucte;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;



import cmsfinitequeuenostag.CFQNSHelper;

public class test {
	protected File f1 ;
	protected File f2 ;
	protected Scanner input1;
	protected Scanner input2;
	protected FileWriter fw;
	protected double timenext;
	public test(){
		f1 = new File("./outputdata/lambda _20_8_2017.csv");
		f2 = new File("./outputdata/muy.csv");
		
		try{
			input1 = new Scanner(f1);
			input2 = new Scanner(f2);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void  writeOnFile(){
		int number = 0;
		NewHelper.reset();
		try {
			fw = new FileWriter("./outputdata/tau.csv");
			while(input1.hasNext()){
				double lambda = Double.parseDouble(input1.nextLine());
				//double muy = Double.parseDouble(input2.nextLine());
				
				NewHelper.setAlpha(0.002);
				//NewHelper.setLamda(5);
				NewHelper.setMuy(0.01);
				NewHelper.theta=0.001;
				NewHelper.jobsqueuecapacity = 500;
				NewHelper.hostNum = 2000;
//				System.out.println("muy ="+muy);
//				System.out.println("lambda="+lambda);
				calculateTau();
				System.out.println(timenext+"\n");
				number++;
				
				fw.write(timenext+"\n");
			}
			System.out.println("number"+number);
			System.out.println("done");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public  void calculateTau(){
	//	System.out.println("dang calculate");
		//NewHelper.reset();
		NewHelper.setAlpha(0.002);
		//NewHelper.setLamda(1);
		NewHelper.setMuy(0.001);
		NewHelper.theta=0.0001;
		NewHelper.jobsqueuecapacity = 200;
		NewHelper.hostNum = 200;       
			
        //	System.out.println("muy+"+NewHelper.muy);
		//changeLamd
	    int K = NewHelper.jobsqueuecapacity;
		int c = NewHelper.hostNum;
		 double pi[][] = new double[NewHelper.hostNum+1][NewHelper.jobsqueuecapacity+1];
		 double a[][] = new double[NewHelper.hostNum+1][NewHelper.jobsqueuecapacity+1];  
		 double b[][] = new double[NewHelper.hostNum+11][NewHelper.jobsqueuecapacity+1];  
		 double s1[][] = new double[NewHelper.hostNum+1][NewHelper.jobsqueuecapacity+1];
		for(int i = 0; i<= c; i++){
			for(int j = 0;j <= K; j++){
				pi[i][j] = 0;
				a[i][j] = 0;
				b[i][j] =0;
				s1[i][j] =0;
			}
		}
		pi[0][0] = 2;
		int s = c;
		// i = 0
		b[0][K] = (NewHelper.lamda)/(NewHelper.theta*K+s*NewHelper.alpha);
	//	System.out.println("bok="+b[0][K]);
		for(int j  = K-1; j>=1; j--){
				b[0][j] = NewHelper.lamda/(NewHelper.lamda+ min(j, s, c)*NewHelper.alpha
						+j*NewHelper.theta- (j+1)*NewHelper.theta*b[0][j+1]);
		}
		for(int j  = 1; j <= K; j++){
			pi[0][j] =	b[0][j]*pi[0][j-1];
			//System.out.println("pi[0]["+j+"]= "+pi[0][j]);
		}
		//i =1 	
		for(int j = 1 ; j <= K ; j++){
		// tinh pi[1][1]
			pi[1][1] =pi[1][1]+min(j,c,s)*NewHelper.alpha*pi[0][j]/NewHelper.muy;
		
		}
		//System.out.println(pi[1][1]);
		a[1][K] = Math.min(c,s)*NewHelper.alpha*pi[0][K]/(NewHelper.muy+Math.min(c-1, s)*NewHelper.alpha
				+(K-1)*NewHelper.theta);
		b[1][K] =  NewHelper.lamda/(NewHelper.muy+Math.min(c-1, s)*NewHelper.alpha+
				(K-1)*NewHelper.theta);
		for(int j = K-1; j>=2 ; j--){
			a[1][j] =((NewHelper.muy+j*NewHelper.theta)*a[1][j+1]+min(j,c,s)*NewHelper.alpha*
					pi[0][j])/(NewHelper.muy+NewHelper.lamda+min(j-1,c-1,s)*NewHelper.alpha+
							(j-1)*NewHelper.theta-(NewHelper.muy+j*NewHelper.theta)*b[1][j+1]);
			
			b[1][j] = NewHelper.lamda/(NewHelper.muy+NewHelper.lamda+min(j-1,c-1,s)*NewHelper.alpha+
					(j-1)*NewHelper.theta-(NewHelper.muy+j*NewHelper.theta)*b[1][j+1]);
		}
		for(int j = 2 ; j <= K ; j++){
			pi[1][j] = a[1][j]+ b[1][j]*pi[1][j-1];
		}
		// i = 2 den c-1
		for(int i = 2 ; i < c; i++ ){
			for(int j = i; j<= K;j++){
				pi[i][i] = pi[i][i] +( min(j-i+1,c-i+1,s)*NewHelper.alpha*pi[i-1][j])/(NewHelper.muy*i);
			}
			a[i][K] = Math.min(c-i+1, s)*NewHelper.alpha*pi[i-1][K]/(Math.min(c-i, s)*NewHelper.alpha+
					i*NewHelper.muy+(K-i)*NewHelper.theta);
			b[i][K] = NewHelper.lamda/(Math.min(c-i, s)*NewHelper.alpha+
					i*NewHelper.muy+(K-i)*NewHelper.theta);
			
			for(int j = K-1; j >= i+1; j--){
				s1[i][j] = NewHelper.lamda + min(j-i, c-i, s)*NewHelper.alpha+NewHelper.muy*i+
						(j-i)*NewHelper.theta;
				
				a[i][j] =((i*NewHelper.muy+(j-i+1)*NewHelper.theta)*a[i][j+1]+min(j-i+1,c-i+1,s)*NewHelper.alpha*
						pi[i-1][j])/(s1[i][j]-(i*NewHelper.muy+(j+1-i)*NewHelper.theta)*b[i][j+1]);
				b[i][j] = NewHelper.lamda/(s1[i][j]-(i*NewHelper.muy+(j+1-i)*NewHelper.theta)*b[i][j+1]);
				
			}
			for(int j = i+1 ; j<=K; j++){
				pi[i][j] = a[i][j]+b[i][j]*pi[i][j-1];
			}
		}	
	   // i = c
		for(int j = c; j<= K;j++){
			pi[c][c] = (pi[c][c] + min(j-c+1,1,s)*NewHelper.alpha*pi[c-1][j])/(NewHelper.muy*c);
		}
		a[c][K] =	 NewHelper.alpha*pi[c-1][K]/(c*NewHelper.muy+(K-c)*NewHelper.theta);
		b[c][K] = NewHelper.lamda/(c*NewHelper.muy+(K-c)*NewHelper.theta);
		for(int j = K-1; j >= c+1 ; j--){
			a[c][j]=((c*NewHelper.muy+(j+1-c)*NewHelper.theta)*a[c][j+1]+NewHelper.alpha*pi[c-1][j])/
					(NewHelper.lamda+ c*NewHelper.muy+(j-c)*NewHelper.theta-(c*NewHelper.muy
							+(j-c+1)*NewHelper.theta)*b[c][j+1]	);
			b[c][j] = NewHelper.lamda/(NewHelper.lamda+ c*NewHelper.muy+(j-c)*NewHelper.theta-(c*NewHelper.muy
					+(j-c+1)*NewHelper.theta)*b[c][j+1]);
			
			
					
		}
		for(int j= c+1;j <= K ; j++){
			pi[c][j] = a[c][j]+pi[c][j-1]*b[c][j];
		}
		
		// tinh To
		double  temp = 0;
		for(int i  = 0; i <= c; i++ ){
			for(int j = i; j <= K; j++){
				temp = temp + pi[i][j];
				
			}
			System.out.println("temp  ="+temp);
		}
		
		
		// tinh pi[0][0]
		pi[0][0] = 1/temp;
		double temp2 = pi[0][0];
		//System.out.println("temp = "+temp);
		
		for(int i = 0; i<= c; i++){
			for(int j = i;j <= K; j++){
				if(j!=0) pi[i][j] =  pi[i][j]*temp2;
			}
		}
		temp2 = 0;
		for(int i = 0; i <= c; i++)
			for(int j = i+1; j<= K ; j++)
				temp2 = temp2 + pi[i][j]*min(c-i,j-i,s);
		//System.out.println("temp2="+temp2);
		timenext =  1/(NewHelper.alpha*temp2);
		//System.out.println(timenext);
    	
    }
    public static int min(int a, int b ,int c){
		int min =a;
		if(b < min) min = b;
		if(c < min) min = c;
		return min;
	}
    public static int min(int a,int b){
    	int min = a;
    	if(b<a) min =b;
    	return min;
    }
    
		
	
	public static void main(String args[]){
		test t = new test();
		double lambda[]={0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.10,0.11,0.12,0.13,0.14,0.15,0.16,0.17,0.18,0.19,0.2};//0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,7,7.5,8.5,9};
		int len = lambda.length;
		double timenext1[] = new double[lambda.length];
		//t.writeOnFile();
		//NewHelper.setAlpha(alpha);
		//NewHelper.setMuy(1.0/50026);
		//NewHelper.setLamda(15/600.0);
		//t.calculatetimenextversion2();
		for(int i = 0 ; i < lambda.length; i++){
			NewHelper.reset();
			NewHelper.setLamda(lambda[i]);
			t.calculateTau();
			timenext1[i] = t.timenext;
			System.out.println("timenext["+i+"]="+timenext1[i]+"\n");
		}
		//t.calculatetimenextversion2();
		try {
			FileWriter fw1 = new FileWriter("./outputdata/timenext_host=2000_1_alpha=0.002_giam_di_10lan.py");
			fw1.write("import matplotlib.pyplot as plt \n");
			
			fw1.write("lamda=[");
			for(int i = 0 ; i<len-1; i++){
				fw1.write(lambda[i]+",");
			}
			fw1.write(lambda[len-1]+"]");
			fw1.write("\n");
			
			
			fw1.write("timenext=[");
			for(int i = 0 ; i<len-1; i++){
				fw1.write(timenext1[i]+",");
			}
			fw1.write(timenext1[len-1]+"]");
			fw1.write("\n");
			
			fw1.write("plt.plot(lamda,timenext,marker=\"x\")\n");
			fw1.write("plt.show()");
			fw1.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("timenext:"+t.timenext);
	}
}
