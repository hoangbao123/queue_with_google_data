package duthieuthucte;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.core.CloudSim;

import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;

import cmsfinitequeuenostag.CFQNSBroker;
import cmsfinitequeuenostag.CFQNSDatacenter;
import cmsfinitequeuenostag.CFQNSHelper;

public class NewMain {

    public static double[] alpha = {0.02,0.1};
    public static int[] capacity = {500};
    public static double[] listThrUp = {0.8};
    public static double[] listThrDown = {-0.8};
    public static int timetomiddle = 400;
    public static double[] theta = {0.00025,0.0005,0.00075,0.001,0.00125,0.0015,0.00175,0.002,0.00225,0.0025,0.00275,0.003};

	public static void chayvoidulieuthuctekomiddle(){
		int n = theta.length;
		double meanWaitingTimeNoMiddle[] = new double[n];
		double meanNumberSetupServerNoMiddle[] = new double[n]  ;
		double meanNumberOnServerNoMiddle[] = new double[n];
		double meanResponseTime[] =  new double[n];
		double meanWaitingTime[] = new double[n];
		double jobLostRatio;
		double jobLeft[] = new double[n];
		double[] leftJobRatio = new double[n];
		boolean hasMiddle = false;
		
		//double alpha = 0.05;
		CFQNSHelper.isSingleQueue = true;
        System.out.println("Start simulation");
        for(int i=0; i<n; i++){
        	      
	        try{	
			 NewHelper.reset();
	         NewHelper.setAlpha(alpha[0]);
	         NewHelper.thrUP = listThrUp[0];
	         NewHelper.thrDown = listThrDown[0];
	         NewHelper.jobsqueuecapacity =500;
	         NewHelper.hostNum = capacity[0];
	         NewHelper.jobsqueuethresholdup = (int) (NewHelper.jobsqueuecapacity * NewHelper.thrUP);
	         NewHelper.jobsqueuethresholddown = (int) (NewHelper.jobsqueuecapacity * NewHelper.thrDown);
	         NewHelper.theta=theta[i];
	         NewHelper.setTimeOffToMiddle(timetomiddle);
			 
			  // First step: Initialize the CloudSim package. It should be called
			  // before creating any entities.
			  int num_user = 1;   // number of cloud users
			  Calendar calendar = Calendar.getInstance();
			  boolean trace_flag = false;  // mean trace events
			
			  // Initialize the CloudSim library
			  CloudSim.init(num_user, calendar, trace_flag);
			
			  // Second step: Create Datacenters
			  //Datacenters are the resource providers in CloudSim. We need at list one of them to run a CloudSim simulation
			
			  NewDatacenter datacenter0 = NewHelper.createDatacenter("Datacenter_0");
			  datacenter0.state = CFQNSDatacenter.ON;
			  //datacenter0.setStartState(0,(int) (CFQNSHelper.timeOffToMiddle/CFQNSHelper.timenext));
			  datacenter0.setHasMiddle(hasMiddle);
			  Log.printLine("main datacenter id "+datacenter0.getId());
			
			
			  //Third step: Create Broker
			  NewBroker broker = (NewBroker)NewHelper.createBroker();
			
			
			  int brokerId = broker.getId();
			
			  // Sixth step: Starts the simulation
			  double lastclock = CloudSim.startSimulation();
			  // Final step: Print results when simulation is over
			  //List<Cloudlet> newList = broker.getCloudletReceivedList();
			  List<NewCloudlet> newList = broker.getReceivedCloudletList();
			 
			    
			  CloudSim.stopSimulation();
			  
			  //------------------------------print metric------------------------
			  System.out.println("total time simulate: " + lastclock);
	          System.out.println("(without middle) mean waitting time: " + ((NewBroker) broker).getMeanWaittingTime());
	          System.out.println("(withouot middle) mean response time: " + ((NewBroker) broker).getMeanResponseTime());
	
	//  Log.printLine("mean waitting time 2: of "+ newList.size()+" : " + CMSHelper.getMeanWaittingTime(newList));
	
	//          System.out.println("mean jobs queue length : " + datacenter0.getMeanJobsQueueLength());
	          System.out.println("mean Middle server Length: " + datacenter0.getMeanMiddleServerLength());
	
	          System.out.println("mean setup server Length: " + datacenter0.getMeanNumberSetupServer());
	          System.out.println("mean ON server Length: " + datacenter0.getMeanNumberOnServer());
	          System.out.println("num of completed job:"+ datacenter0.getNumberOfCompletedJob());
	          System.out.println("total time no Middle server: " + datacenter0.getTimeNoMiddle());
	          System.out.println("number of job leave:" + datacenter0.getNumberOfLeftJob());
	          System.out.println("number of job (trong khoang thoi gian xet: " + ((CFQNSBroker) broker).getNumberOfJob());
	          System.out.println("**** total job lost: " + datacenter0.getNumberOfJobLost());
	          System.out.println("**** ti le job lost = joblost / numberofjob: " +datacenter0.getNumberOfJobLost()+" / "+ datacenter0.number+ " = "+ datacenter0.getNumberOfJobLost() / (datacenter0.number));
	          System.out.println("so  job  "+broker.job);
	          System.out.println("total vm: " + CFQNSHelper.getVmid());
	          System.out.println("total sub datacenter create: " + CFQNSHelper.listSubDatacenter.size());
	          System.out.println("so lan tat may ON  " + CFQNSHelper.extraCount);
	          System.out.println();
			  //------------------------------------------------------------------
			  meanWaitingTimeNoMiddle[i] = ((NewBroker) broker).getMeanWaittingTime();
			  meanNumberOnServerNoMiddle[i] = datacenter0.getMeanNumberOnServer();
			  meanNumberSetupServerNoMiddle[i] = datacenter0.getMeanNumberSetupServer();
			  jobLeft[i] = datacenter0.getNumberOfLeftJob();
			  leftJobRatio[i]= datacenter0.getNumberOfLeftJob()/datacenter0.number;
			 // printCloudletList(newList);
			 // writeCloudletList(newList,"./outputdata/11_9_2017_komiddle_1");
			}catch(Exception e){
				e.printStackTrace();
			}
        }
        FileWriter fw = null;
        try{
        	fw = new FileWriter("ket_qua_du_lieu_google_no_middle_alpha_"+NewHelper.alpha+"_hostNum_"+NewHelper.hostNum+
        			"_QueueCapacity_"+NewHelper.jobsqueuecapacity);
        	fw.write("ko middle ");
        	fw.write("\n----------------------------------------------------------------\n");
	        //--------write theta----------------------------
        	fw.write("theta = [");
	        for (int i = 0; i < n - 1; i++) {
	            System.out.printf("%.2f, ", theta[i]);
	            fw.write(theta[i] + ", ");
	        }
	        System.out.printf("%.2f ];", theta[n - 1]);
	        fw.write(theta[n - 1] + "]\n");
	        
	        //--------write mean waiting time-----------
	        System.out.print("mean waitting time = [");
            fw.write("mean_waitting_time_nomiddle_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+" = [");
            for (int i = 0; i < n - 1; i++) {
                System.out.printf("%.2f, ", meanWaitingTimeNoMiddle[i]);
                fw.write(meanWaitingTimeNoMiddle[i] + ", ");
            }
            System.out.printf("%.2f ];", meanWaitingTimeNoMiddle[n - 1]);
            fw.write(meanWaitingTimeNoMiddle[n - 1] + "]\n");
            //--------------------write mean setup server--------------------------
            System.out.print("mean number setup server = [");
            fw.write("mean_number_of_setup_server_nomiddle_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+" = [");
            for (int i = 0; i < n - 1; i++) {
                System.out.printf("%.2f ,", meanNumberSetupServerNoMiddle[i]);
                fw.write(meanNumberSetupServerNoMiddle[i] + ", ");
            }
            System.out.printf("%.2f ];", meanNumberSetupServerNoMiddle[n - 1]);
            fw.write(meanNumberSetupServerNoMiddle[n - 1] + "]\n");
            //--------------write mean on server-----------
            System.out.print("mean number On server = [");
            fw.write("mean_number_of_on_server_nomiddle_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+"  =[");
            for (int i = 0; i < n - 1; i++) {
                System.out.printf("%.2f ,", meanNumberOnServerNoMiddle[i]);
                fw.write(meanNumberOnServerNoMiddle[i] + ", ");
            }
            System.out.printf("%.2f ];", meanNumberOnServerNoMiddle[n - 1]);
            fw.write(meanNumberOnServerNoMiddle[n - 1] + "]\n");
           //--------------write job left ratio------
            System.out.printf("job left ratio = [");
            fw.write("job_left_ratio_nomiddle_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+"  = [");
            for (int i = 0; i < n - 1; i++) {
              System.out.printf(  leftJobRatio[i]+",");
              fw.write(leftJobRatio[i] + ", ");
            }
            System.out.print( leftJobRatio[n - 1]+"]");
            fw.write(leftJobRatio[n - 1] + "]\n");	
            
	        fw.close();
        }catch(Exception e){
        	e.printStackTrace();
        	
        }finally{
        
        }
	}
	public static void chayvoidulieuthuctecomiddle(){
		int n = theta.length;
		double meanWaitingTimeMiddle[] = new double[n];
		double meanNumberSetupServerMiddle[] = new double[n]  ;
		double meanNumberOnServerMiddle[] = new double[n];
		double[] meanNumberMiddleServer = new double[n];
        double[] meanNumberOffToMiddleServer = new double[n];
		double jobLeft[] = new double[n];
		double leftJobRatio[] = new double[n];
		boolean hasMiddle = true;
		//double alpha = 0.05;
		CFQNSHelper.isSingleQueue = true;
        
		System.out.println("Start simulation");
		for(int i = 0 ; i<n;i++){	
			try{	
				 NewHelper.reset();
		         NewHelper.setAlpha(alpha[0]);
		         NewHelper.thrUP = listThrUp[0];
		         NewHelper.thrDown = listThrDown[0];
		      //   NewHelper.setLamda(3);
		         NewHelper.jobsqueuecapacity = 500;
		         NewHelper.hostNum = capacity[0];
		        // NewHelper.setMuy(0.05);
		         NewHelper.jobsqueuethresholdup = (int) (NewHelper.jobsqueuecapacity * NewHelper.thrUP);
		         NewHelper.jobsqueuethresholddown = (int) (NewHelper.jobsqueuecapacity * NewHelper.thrDown);
		         NewHelper.theta = theta[i];
		         NewHelper.setTimeOffToMiddle(timetomiddle);
					
				  // First step: Initialize the CloudSim package. It should be called
				  // before creating any entities.
				  int num_user = 1;   // number of cloud users
				  Calendar calendar = Calendar.getInstance();
				  boolean trace_flag = false;  // mean trace events
				
				  // Initialize the CloudSim library
				  CloudSim.init(num_user, calendar, trace_flag);
				
				  // Second step: Create Datacenters
				  //Datacenters are the resource providers in CloudSim. We need at list one of them to run a CloudSim simulation
				  NewDatacenter datacenter0 = NewHelper.createDatacenter("Datacenter_0");
				  datacenter0.state = CFQNSDatacenter.ON;
				  //datacenter0.setStartState(0,(int) (CFQNSHelper.timeOffToMiddle/CFQNSHelper.timenext));
				  datacenter0.setHasMiddle(hasMiddle);
				  Log.printLine("main datacenter id "+datacenter0.getId());
				
				
				  //Third step: Create Broker
				  NewBroker broker = (NewBroker)NewHelper.createBroker();
				
				
				  int brokerId = broker.getId();
				
				  // Sixth step: Starts the simulation
				  double lastclock = CloudSim.startSimulation();
				  // Final step: Print results when simulation is over
				  //List<Cloudlet> newList = broker.getCloudletReceivedList();
				  List<NewCloudlet> newList = broker.getReceivedCloudletList();
				 
				    
				  CloudSim.stopSimulation();
				  
				  //------------------------------print metric------------------------
				  System.out.println("total time simulate: " + lastclock);
		          System.out.println("(with middle) mean waitting time: " + ((NewBroker) broker).getMeanWaittingTime());
		          System.out.println("(with middle) mean response time: " + ((NewBroker) broker).getMeanResponseTime());
		
		//  Log.printLine("mean waitting time 2: of "+ newList.size()+" : " + CMSHelper.getMeanWaittingTime(newList));
		
		//          System.out.println("mean jobs queue length : " + datacenter0.getMeanJobsQueueLength());
		          System.out.println("mean Middle server Length: " + datacenter0.getMeanMiddleServerLength());
		          //System.out.println("mean Off to Middle server Length: " + datacenter0.getMeanNumberOff2MiddleServer());
		
		          System.out.println("mean setup server Length: " + datacenter0.getMeanNumberSetupServer());
		          System.out.println("mean ON server Length: " + datacenter0.getMeanNumberOnServer());
		          System.out.println("mean Off to Middle server Length: " + datacenter0.getMeanNumberOff2MiddleServer());
		          System.out.println("total time no Middle server: " + datacenter0.getTimeNoMiddle());
		          System.out.println("num of left job:"+ datacenter0.getNumberOfLeftJob());
		          System.out.println("num of completed job:"+ datacenter0.getNumberOfCompletedJob());
		          System.out.println("number of job (trong khoang thoi gian xet: " + ((CFQNSBroker) broker).getNumberOfJob());
		          System.out.println("**** total job lost: " + datacenter0.getNumberOfJobLost());
		          System.out.println("number of job leave:" + datacenter0.getNumberOfLeftJob());
		          System.out.println("**** ti le job lost = joblost / numberofjob: " +datacenter0.getNumberOfJobLost()+" / "+ datacenter0.number+ " = "+ datacenter0.getNumberOfJobLost() / datacenter0.number);
		          //System.out.println("total vm: " + CFQNSHelper.getVmid());
		          System.out.println("so  job  "+broker.job);
		          System.out.println("total sub datacenter create: " + CFQNSHelper.listSubDatacenter.size());
		          System.out.println("so lan tat may ON  " + CFQNSHelper.extraCount);
		          System.out.println();
				  //------------------------------------------------------------------
		          meanWaitingTimeMiddle[i] = ((NewBroker) broker).getMeanWaittingTime();
				  meanNumberOnServerMiddle[i] = datacenter0.getMeanNumberOnServer();
				  meanNumberOffToMiddleServer[i] = datacenter0.getMeanNumberOff2MiddleServer() ;
				  meanNumberSetupServerMiddle[i] = datacenter0.getMeanNumberSetupServer();
				  meanNumberMiddleServer[i] = datacenter0.getMeanMiddleServerLength();
				  jobLeft[i] = datacenter0.getNumberOfLeftJob();
				  leftJobRatio[i]= datacenter0.getNumberOfLeftJob()/datacenter0.number;
				  //printCloudletList(newList);
				//  writeCloudletList(newList,"./outputdata/11_9_2017_dulieuthucte_comiddle_1.csv");
				}catch(Exception e){
					e.printStackTrace();
				}
		}
		FileWriter fw = null;
        try{
        	fw = new FileWriter("ket_qua_du_lieu_google_CO_middle_alpha_"+NewHelper.alpha+"_hostNum_"+NewHelper.hostNum+
        			"_QueueCapacity_"+NewHelper.jobsqueuecapacity);
	        //--------write theta----------------------------
        	fw.write("Co middle ");
        	fw.write("\n----------------------------------------------------------------\n");
        	fw.write("theta = [");
	        for (int i = 0; i < n - 1; i++) {
	            System.out.printf("%.2f, ", theta[i]);
	            fw.write(theta[i] + ", ");
	        }
	        System.out.printf("%.2f ];", theta[n - 1]);
	        fw.write(theta[n - 1] + "]\n");
	        
	        //--------write mean waiting time-----------
	        System.out.print("mean waitting time = [");
            fw.write("mean_waitting_time_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+"= [");
            for (int i = 0; i < n - 1; i++) {
                System.out.printf("%.2f, ", meanWaitingTimeMiddle[i]);
                fw.write(meanWaitingTimeMiddle[i] + ", ");
            }
            System.out.printf("%.2f ];", meanWaitingTimeMiddle[n - 1]);
            fw.write(meanWaitingTimeMiddle[n - 1] + "]\n");
            //--------------------write mean setup server--------------------------
            System.out.print("mean number setup server = [");
            fw.write("mean_number_of_setup_server_withmiddle_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+" = [");
            for (int i = 0; i < n - 1; i++) {
                System.out.printf("%.2f ,", meanNumberSetupServerMiddle[i]);
                fw.write(meanNumberSetupServerMiddle[i] + ", ");
            }
            System.out.printf("%.2f ];", meanNumberSetupServerMiddle[n - 1]);
            fw.write(meanNumberSetupServerMiddle[n - 1] + "]\n");
            //--------------write mean on server-----------
            System.out.print("mean number On server_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+" = [");
            fw.write("mean_number_of_on_server_withmiddle_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+"  =[");
            for (int i = 0; i < n - 1; i++) {
                System.out.printf("%.2f ,", meanNumberOnServerMiddle[i]);
                fw.write(meanNumberOnServerMiddle[i] + ", ");
            }
            System.out.printf("%.2f ];", meanNumberOnServerMiddle[n - 1]);
            fw.write(meanNumberOnServerMiddle[n - 1] + "]\n");
           //------------------write mean number middle server-----
            fw.write("mean_number_of_middle_server_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+" = [");
            for (int i = 0; i < n - 1; i++) {
                System.out.printf("%.2f ,", meanNumberMiddleServer[i]);
                fw.write(meanNumberMiddleServer[i] + ", ");
            }
            System.out.printf("%.2f ];", meanNumberMiddleServer[n - 1]);
            fw.write(meanNumberMiddleServer[n - 1] + "]\n");
            //----write mean number off to middle server 
            System.out.print("mean number Off to Middle server = [");
            fw.write("mean_number_of_off_to_middle_server_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+" = [");
            for (int i = 0; i < n - 1; i++) {
                System.out.printf("%.2f ,", meanNumberOffToMiddleServer[i]);
                fw.write(meanNumberOffToMiddleServer[i] + ", ");
            }
            System.out.printf("%.2f ];", meanNumberOffToMiddleServer[n - 1]);
            fw.write(meanNumberOffToMiddleServer[n - 1] + "]\n");
           //--------------write job left ratio------
            System.out.printf("job left ratio = [");
            fw.write("job_left_ratio_withmiddle_hostnum_"+NewHelper.hostNum+"_queuecapacity_"+NewHelper.jobsqueuecapacity+"  = [");
            for (int i = 0; i < n - 1; i++) {
              System.out.printf(  leftJobRatio[i]+",");
              fw.write(leftJobRatio[i] + ", ");
            }
            System.out.print( leftJobRatio[n - 1]+"]");
            fw.write(leftJobRatio[n - 1] + "]\n");	
            
	        fw.close();
        }catch(Exception e){
        	e.printStackTrace();
        	
        }finally{
        	
        }
		
	}
	public static void printCloudletList(List<NewCloudlet> list){
		int size = list.size();
		String indent = "    ";
		NewCloudlet cl;
		
		for(int i= 0 ; i < size ; i++){
			cl = list.get(i);
			System.out.println("CloudletID"+indent+"starttime"+indent+"execution"+indent+"finishTime \n");
			System.out.println(cl.getId()+indent+cl.getSubmitTime()+indent+cl.getExecutionTime()+indent+cl.getFinishTime());

			
		}
	}
	public static void writeCloudletList(List<NewCloudlet> list,String fileName){
		FileWriter fw = null;
		try {
			 fw = new FileWriter(fileName);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int size = list.size();
		String indent = ",";
		NewCloudlet cl;
		DecimalFormat dft = new DecimalFormat("###.##");
		double d ;
		try {
			fw.write("CloudletID"+indent+"starttime"+indent+"execution"+indent+"finishTime "+indent+"timedatacenter nhan"+indent+"time bat dau chay"+indent+"waiting time"+"\n");
			for(int i= 0 ; i < size ; i++){
				cl = list.get(i);
				 d = cl.getTimeStartExe()-cl.getTimeCreate();
				fw.write(cl.getId()+indent+cl.getSubmitTime()+indent+cl.getExecutionTime()+indent+cl.getFinishTime()+indent+cl.getTimeCreate()+indent+cl.getTimeStartExe()+indent+d+"\n");
				
			}
		} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}

			
	}
	
	
	public static void main(String args[]){
		Log.disable();
		chayvoidulieuthuctekomiddle();
		chayvoidulieuthuctecomiddle();
//		for (int i = 0; i < theta.length; i++) {
//			System.out.println(theta[i]+" ");
//		}
		
	}
}
