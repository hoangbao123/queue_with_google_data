package duthieuthucte;
import org.cloudbus.cloudsim.UtilizationModel;

import cmsfinitequeuenostag.CFQNSJob;
public class NewCloudlet extends CFQNSJob{
	protected double submitTime;
	protected double executionTime;
	protected double finishTime;
	protected long id;
	

	public double getSubmitTime() {
		return submitTime;
	}
	public long getId(){
		return id;
	}
	@Override
	public String toString() {
		return "NewCloudlet [submitTime=" + submitTime + ", executionTime=" + executionTime + ", finishTime="
				+ finishTime + ", id=" + id + "]";
	}
	public void setId(long id){
		this.id = id;
	}
	public void setSubmitTime(double submitTime) {
		this.submitTime = submitTime;
	}

	public double getExecutionTime() {
		return executionTime;
	}

	public void setExecutionTime(double executionTime) {
		this.executionTime = executionTime;
	}
	public double getFinishTime(){
		return finishTime;
	}
	public void setFinishTime(double t){
		this.finishTime = t;
	}
	

}
