package duthieuthucte;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

import cmsfinitequeuenostag.CFQNSBroker;
import cmsfinitequeuenostag.CFQNSDatacenter;
import cmsfinitequeuenostag.CFQNSHelper;
import cmsfinitequeuenostag.CFQNSHost;
import cmsfinitequeuenostag.CFQNSJob;
import cmsfinitequeuenostag.CFQNSVmAllocationPolicy;
public class NewHelper extends CFQNSHelper{
	public static void reset(){
		brokerId = -1;
        timenext = 0;

        vmid = 0;
        extraCount = 0;
        jobsqueuecapacity = 500;
        thrUP = 0.7;
        thrDown = 0.5;
        jobsqueuethresholdup = (int) (jobsqueuecapacity * thrUP);
        jobsqueuethresholddown = (int) (jobsqueuecapacity * thrDown);
        mainDatacenterId = -1;

        listSubDatacenter = new ArrayList<>();
//        hostListStatic = null;

       
        vmMips = 100000;
        hostNum = 10000; // phai thoa man dieu kien  hostnum * muy >  lamda

        
        lamda = 0.1; // thoi gian trung binh giua 2 job la 1/lamda
        muy = 0.1;  // thoi gian trung binh de complete 1 jobs laf 1/muy
        controlTime = 0.1; // thoi gian cho moi vong lap trong thuat toan bat server
        timeOffToMiddle = 120;
        alpha = 0.05; // thoi gian trung binh de bat may la 1/alpha

        cmsdatacenter = null;

        mainBroker = null;
        totalTimeSimulate = 2.5e6; // tong cong thoi gian mo phong
        timeStartSimulate = 5e5; // thoi gian bat dau dem

        
	}
	public static DatacenterBroker createBroker(){

        DatacenterBroker broker = null;
        try {
            broker = new NewBroker("Broker", lamda);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        setBrokerId(broker.getId());
        mainBroker = (NewBroker)broker;
        return broker;
    } 
	 public static NewDatacenter createDatacenter(String name) {
	        // Here are the steps needed to create a PowerDatacenter:
	        // 1. We need to create a list to store
	        //    our machine
	        List<Host> hostList = new ArrayList<Host>();
	        List<Host> hostListOn = new ArrayList<Host>();
	        // 2. A Machine contains one or more PEs or CPUs/Cores.
	        // In this example, it will have only one core.
	        List<Pe> peList = new ArrayList<Pe>();

	        int mips = 150000;

	        // 3. Create PEs and add these into a list.
	        peList.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating

	        //4. Create Host with its id and list of PEs and add them to the list of machines
	        int hostId=0;
	        int ram = 2048; //host memory (MB)
	        long storage = 1000000; //host storage
	        int bw = 10000;

	        for (int i = 0; i< hostNum; i++) {
	            hostList.add(
	                    new CFQNSHost(
	                            i,
	                            new RamProvisionerSimple(ram),
	                            new BwProvisionerSimple(bw),
	                            storage,
	                            peList,
	                            new VmSchedulerTimeShared(peList)
	                    )
	            ); // This is our machine
	        }

//	        hostListStatic = hostList;
	        // 5. Create a DatacenterCharacteristics object that stores the
	        //    properties of a data center: architecture, OS, list of
	        //    Machines, allocation policy: time- or space-shared, time zone
	        //    and its price (G$/Pe time unit).
	        String arch = "x86";      // system architecture
	        String os = "Linux";          // operating system
	        String vmm = "Xen";
	        double time_zone = 10.0;         // time zone this resource located
	        double cost = 3.0;              // the cost of using processing in this resource
	        double costPerMem = 0.05;		// the cost of using memory in this resource
	        double costPerStorage = 0.001;	// the cost of using storage in this resource
	        double costPerBw = 0.0;			// the cost of using bw in this resource
	        LinkedList<Storage> storageList = new LinkedList<Storage>();	//we are not adding SAN devices by now

	        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
	                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);


	        // 6. Finally, we need to create a PowerDatacenter object.
	        NewDatacenter datacenter = null;
	        try {
	            datacenter = new NewDatacenter(name, characteristics,
	                    new CFQNSVmAllocationPolicy(hostListOn),
	                    storageList, 0,
	                    alpha , muy, lamda, controlTime, timeOffToMiddle );
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        setMainDatacenterId(datacenter.getId());
	        listSubDatacenter.add(datacenter);
	        // can thay doi phuong thuc tren
//	        datacenter.controlMiddleHost();
	        //cmsdatacenter = datacenter;

//	        datacenter.listHostOff.addAll(hostListStatic);
	        return datacenter;
	    }
	 public static NewCloudlet createJob(int _brokerId){
		 return new NewCloudlet();
	 }
}
