package duthieuthucte;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthSeparatorUI;

import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;



import cmsfinitequeuenostag.CFQNSConstants;
import cmsfinitequeuenostag.CFQNSDatacenter;
import cmsfinitequeuenostag.CFQNSHelper;
import cmsfinitequeuenostag.CFQNSHost;
import cmsfinitequeuenostag.CFQNSJob;
import cmsfinitequeuenostag.StdRandom;

public class NewDatacenter extends CFQNSDatacenter{
	protected File f1 ;
	//protected File f2 ;
	protected Scanner input1;
	//protected Scanner input2;
	protected  double timenext=12;
	protected boolean changeLambda = false;
	public NewDatacenter(String name, DatacenterCharacteristics characteristics, VmAllocationPolicy vmAllocationPolicy,
			List<Storage> storageList, double schedulingInterval, double _alpha, double _muy, double _lamda,
			double controltime, double _timeOffToMiddle) throws Exception {
		super(name, characteristics, vmAllocationPolicy, storageList, schedulingInterval, _alpha, _muy, _lamda, controltime,
				_timeOffToMiddle);
		// TODO Auto-generated constructor stub
		f1 = new File("./outputdata/tau.csv");
	//	f2 = new File("muy.csv");
		try{
			input1 = new Scanner(f1);
			//input2 = new Scanner(f2);
		}catch(Exception e){
			e.printStackTrace();
		}
		//sendNow(getId(),CFQNSConstants.ChangeLambda);
		//changeLambda();
		//calculateTau();
		
	}
	public void processCloudletSubmit(SimEvent ev,boolean ack){
//		if(CloudSim.clock()>NewHelper.totalTimeSimulate){
//			System.out.println("done");
//			CloudSim.terminateSimulation();
//		}
		if(!changeLambda){
			changeLambda();
			changeLambda = true;
		}
		//System.out.println("da nhan cloudlet");
		
	//	
		//if(number>600)CloudSim.terminateSimulation();
		if(CFQNSHelper.timeStartSimulate < CloudSim.clock()){
    		start = true;
    	}

        if(state == CFQNSDatacenter.WAITING) toON();
        updateCloudletProcessing(); 
        try {
            // gets the Cloudlet object
        	if(start)	number++;
           NewCloudlet cl = (NewCloudlet) ev.getData();
           cl.setTimeCreate(CloudSim.clock());
          // cl.setSubmitTime(CloudSim.clock());
         //System.out.println(CloudSim.clock());
   //      //   CFQNSJob  cl = (CFQNSJob) ev.getData();
            //System.out.println(cl.toString());
            // tim cho cloudlet mot host ON:
            boolean hasAOnHost = false;
            //tim xem co host nao ON ma ko co jobs nao dang thuc hien tren do ko
            for (Host h : listHostON) {
                if (((CFQNSHost)h).getJob() == null) {

//                    Log.printLine("host "+h.getId()+" chay "+
//                            ((CMSHost) h).getCurrentvm().getCllíoudletScheduler().runningCloudlets());

                    System.out.println("datacenter "+ getName() + "co server ON khong co job");

                    jobsqueue.add(cl);
                    jobsqueue.poll();
                    assignJobToHost(cl, h);
                    hasAOnHost = true;
                    break;
                }

            }
           // System.out.println("hot quue"+hostOnNumber.getsize());
          //  System.out.println("quue"+listHostON.size());
            // neu ko tim duoc host ON, chi don gian la dua cloud vao hang doi va bat may tu middle sang ON
            // va bat may tu Middle sang ON
            if (!hasAOnHost) {
            //	System.out.println("jobquee"+jobsqueue.getsize());
                // kiem tra xem datacenter con kha nang chua job khong
                if(getSystemLength() < CFQNSHelper.jobsqueuecapacity){
                    jobsqueue.add(cl);
                 //   System.out.println("add job vao queue");
                   deleteJobInQueue(cl);
                }
                else{
                    Log.printLine("!!!!!!!!!!!! block job");
                    // datacenter het kha nang cohua
                    // tra cloudlet chua hoan thanh nay ve cho broker
                    // va dem luong job lost
                //    System.out.println("job lost1");
                    if (startCountJobLost) {
                        nummberOfJobLost ++;
                     //   System.out.println("job lost");
//                        Log.printLine("dem job lost");

                    } else {
                        if (CloudSim.clock() > CFQNSHelper.timeStartSimulate) startCountJobLost = true;
                    }

                    Log.printLine("datacenter "+getId()+" day tai thoi diem "+CloudSim.clock());
                    sendNow(CFQNSHelper.brokerId, CloudSimTags.CLOUDLET_RETURN, cl);
                }

//               
                if(getHasMiddle()) checkAndTurnMiddleToOn();
                else checkAndTurnOffToOn();
            }

        } catch (ClassCastException c) {
            Log.printLine(getName() + ".processCloudletSubmit(): " + "ClassCastException error.bao");
            c.printStackTrace();
        } catch (Exception e) {
            Log.printLine(getName() + ".processCloudletSubmit(): " + "Exception error.");
            e.printStackTrace();
        }

        checkCloudletCompletion();
		
	}
	 protected void deleteJobInQueue(NewCloudlet cl){
	    	double t1 = StdRandom.exp(NewHelper.theta);
	    	send(getId(), t1,CFQNSConstants.ProcessJobLeave,cl);
	    	//System.out.println("tau = "+CFQNSHelper.timenext+"timedelay= "+t1 );
	 }
	 protected void processJobLeave(SimEvent ev){
	    	NewCloudlet cl = (NewCloudlet)ev.getData();
	    	//System.out.println("ham ngoai");
	    	if(jobsqueue.contains(cl)){
	    		//System.out.println("ham trong");
	    		jobsqueue.deleteJob(cl);
	    		if(start) numberOfJobLeave++;
	    		//Log.printLine("So job roi di: "+count+"job so: "+cl.getTimeCreate());
	        	//Log.printLine("So job roi di: "+count+"job so: "+((CMSSJob)ev.getData()).getCloudletId());
	    		//xoa job tra ve true neu xoa thanh cong
	    		if(jobsqueue.isEmpty() ){ 
		    			while(listHostInSetupMode.size()>0){
		    					Host h = (Host) listHostInSetupMode.get(listHostInSetupMode.size()-1);
		    				((CFQNSHost)h).isSetUpmode = false;
				            listHostInSetupMode.remove(listHostInSetupMode.size() - 1);
				            hostSetupNumber.poll();
		
				            listHostOff.add(h);
		    			
		    			}
	    			
	    			  		
	    		}
	    		else{
	    			if(jobsqueue.getsize() < listHostInSetupMode.size()){
		    			if(listHostInSetupMode.size()>0){
		    				Host h = (Host) listHostInSetupMode.get(listHostInSetupMode.size()-1);
		    				((CFQNSHost)h).isSetUpmode = false;
				            listHostInSetupMode.remove(listHostInSetupMode.size() - 1);
				            hostSetupNumber.poll();
		
				            listHostOff.add(h);
		    			}
	    			}	
	    		}
//	    	}//neu khong xoa thanh cong thi job da duoc nhan, ko co gi xay ra
	    	}
	    }
	 
	protected void processJobComplete(SimEvent ev) {
        NewCloudlet job =(NewCloudlet) ev.getData();
        ((CFQNSHost)job.getHost()).setJob(null);
        if(start) numberOfCompletedJob++;
        //System.out.println("job da hoan thanh "+CloudSim.clock());
        //Log.printLine("job hoan thanh:"+count2);
        job.setFinishTime(CloudSim.clock());
        Log.printLine("job hoan thanh voi thoi gian cho la " + (job.getTimeStartExe() - job.getTimeCreate()));

//      Log.printLine("so host on: " + listHostON.size() + " so host off:" + listHostOff.size() + " so host middle: " + listHostMIDDLE.getsize());

//      Log.printLine(CloudSim.clock() + " : cloudlet " + cl.getCloudletId() + " complete");

        sendNow(CFQNSHelper.brokerId, CloudSimTags.CLOUDLET_RETURN, job);

        // neu cloudlet duoc da hoan thanh
        // kiem tra hang doi va tat host:
        if (!jobsqueue.isEmpty()) { // neu co
            // chuyen ngay cloudlet do cho host vua thuc hien xong cloudlet do
            assignJobToHost(jobsqueue.poll(), job.getHost());
            // kiem tra tiep neu hang doi khong con thi tat may dang trong setup mode
            turnOffAHostInSetupMode();
        } else { // neu hang doi khong con
            // tat host vua thuc hien xong di
            Log.printLine("hang doi het job -> tat may on di");
            turnOffHostOn(job.getHost());

            // tat host o trang thai setup di
            turnOffAHostInSetupMode();
            if(listHostON.isEmpty()) toOFForWAITING();
        }
        // sau khi xu ly ben tren, luong job trong he thong giam xuong
        // bao cho broker de giai phong job trong buffer:
        // !!!!! chu y cho nay chua giai quyet duoc viec phai tat may ON
        // thi moi giam duoc do dai he thong
        // boi vi may ON do ko nen tat ma co the thuc hien luon job release tu buffer
        // tam thoi cu de the
        CFQNSHelper.mainBroker.releaseBuffer();
    }

	 protected void processOtherEvent(SimEvent ev) {
	        switch (ev.getTag()) {
	            // Resource characteristics inquiry
	            case CFQNSConstants.TurnONSuccess:
	                processTurnONSuccess(ev);
	                break;

	            // Resource dynamic info inquiry
	            case CFQNSConstants.MiddleSucess:
	                processMiddleSuccess(ev);
	                break;
	            case CFQNSConstants.ControlMiddleHostEvent:
	                controlMiddleHost(ev);
	                break;
	            case CFQNSConstants.JobComplete:
	                processJobComplete(ev);
	                break;
	            case CFQNSConstants.InitSubsystemSuccess:
	                processInitSubsystemSuccess(ev);
	                break;
	            case CFQNSConstants.ProcessJobLeave :
	            	processJobLeave(ev);
//	            	{
//	            		int x = 0;
//	            		x++;
//	            	}
	            	break;
	            case CFQNSConstants.ChangeLambda:
	            	{
	            	//	System.out.println("da nha su kien");
	            		changeLambda();
	            	}
	           
	            	break;
	            default:
	                if (ev == null) {
	                    Log.printLine(getName() + ".processOtherEvent(): Error - an event is null.");
	                }
	                break;
	        }
	    }
	protected  void changeLambda(){
		//System.out.print("time next="+timenext);
		
		String str1;

		if(input1.hasNext()){
			str1 = input1.nextLine();
			
//			str2 = input2.nextLine();
////			System.out.println("str1:"+str1);
////			System.out.println("str2:"+str2);
//			NewHelper.setLamda(Double.parseDouble(str1)/600.0);
//			NewHelper.setMuy(1.0/Double.parseDouble(str2));
//			int delay = 600;
//			send(getId(),delay,CFQNSConstants.ChangeLambda);
//			//System.out.println("cloud time"+CloudSim.clock());
//			calculateTau();
//		}
////		
			timenext = Double.parseDouble(str1);
			int delay = 600;
			send(getId(),delay,CFQNSConstants.ChangeLambda);
		}
		//else CloudSim.terminateSimulation();
	}
	
	protected void assignJobToHost(CFQNSJob cl, Host host){
		//System.out.println("dang gan cloudlet, chay cloude");
		cl.setHost(host);
		((CFQNSHost)host).setJob(cl);
		
//		if(cl instanceof NewCloudlet){
			//System.out.println("assigning");
			NewCloudlet job = (NewCloudlet)cl;
			send(getId(),job.getExecutionTime(),CFQNSConstants.JobComplete,cl);
			//send(getId(),StdRandom.exp(muy),CFQNSConstants.JobComplete,cl);
		
		
	}
	   public void controlMiddleHost(SimEvent ev) {

	        // kiem tra event nay la event moi hay event cu
	        if(state == CFQNSDatacenter.ON) {
	            int et = ((Integer) ev.getData()).intValue();
	            if (et == eventNum) { // neu day la event moi
	                if (state == CFQNSDatacenter.ON) {
	                    if (getHasMiddle()) {
	                        
	                        if (!listHostOff.isEmpty()) {
	                            turnAOffToMiddle();
	                        }

	                        else {
//	                            System.out.println("********** het may off ");
	                        }


	                        send(getId(), timenext, CFQNSConstants.ControlMiddleHostEvent, new Integer(eventNum));
	                    }
	                }
	            }
	        }

	    }
	   public void init(){
	        if(state == CFQNSDatacenter.OFF) {
	            state = CFQNSDatacenter.INIT;
	            timestartinit = CloudSim.clock();
//	        System.out.println("init datacenter "+getId());
	            int numberMiddle = (int) (CFQNSHelper.timeOffToMiddle / timenext);
	            for (int i = 0; i < numberMiddle; i++) {

	                hostOff2MiddleNumber.add(new Object());
	            }

	            send(getId(), CFQNSHelper.timeOffToMiddle, CFQNSConstants.InitSubsystemSuccess, new Integer(eventNum));

	        }
	    }
	   protected void processMiddleSuccess(SimEvent ev) {
	 //       System.out.println(getId()+" bat middle thanh cong "+hostOff2MiddleNumber.getsize());
//	        hostOff2MiddleNumber.poll();
	        Host h = (Host) ev.getData();
//	        System.out.println("bat sang middle thanh cong");
	        if( state != CFQNSDatacenter.ON) {
	            if(state == CFQNSDatacenter.WAITING){
	                int numberofmiddletokeep = (int)(CFQNSHelper.timeOffToMiddle / timenext);
	                if(listHostMIDDLE.getsize() < numberofmiddletokeep) {

	                    listHostMIDDLE.add(h);
	                    hostOff2MiddleNumber.poll();
//	                    Log.printLine("!!!! bat trong waiting thanh cong. so middle dang co"+listHostMIDDLE.getsize());
	                    if (!jobsqueue.isEmpty()) {

	                        checkAndTurnMiddleToOn();
	                    }
	                    else {
//	            if(isSubSystem)
	                        if(listHostON.isEmpty()) toOFForWAITING();
	                    }
	                } else {
	                    listHostOff.add(h);
	                    hostOff2MiddleNumber.poll();
	                }
	            }
	            else {
	                // chi khi nao may o trang thai ON thi moi co thuat toan
	                // bat may tu off sang middle
	                // init thi da co event khac xu ly
	                // neu datacenter ko o trang thai ON (la OFF hoac Waiting)
	                // tat di

	                // tat di do day la cluster da bi turn off
	                listHostOff.add(h);


	            }
//	            System.out.println("--------- so may ON: " + listHostON.size() + " SETUP " + listHostInSetupMode.size() + " MIDDLE " + listHostMIDDLE.getsize() + " OFF " + listHostOff.size());

	            return;
	        }
	        else {
//	        Log.printLine(CloudSim.clock()+ " : host "+h.getId()+" turn to Middle success");
	            listHostMIDDLE.add(h);
	            hostOff2MiddleNumber.poll();
	            if (!jobsqueue.isEmpty()) {

	                checkAndTurnMiddleToOn();
	            } else {
//	            if(isSubSystem)
	                if (listHostON.isEmpty()) toOFForWAITING();
	            }
	        }
//	        System.out.println("--------- so may ON: " + listHostON.size() + " SETUP " + listHostInSetupMode.size() + " MIDDLE " + listHostMIDDLE.getsize() + " OFF " + listHostOff.size());

	    }
	   public void toWAITING(){ // from ON
	        if(state == CFQNSDatacenter.ON) {


	            Log.printLine("to waiting datacenter " + getId());
	            if (state == CFQNSDatacenter.WAITING) return;
	            numberONQueue.poll();
//	            System.out.println("number ON queue " + numberONQueue.getsize());

	            numberWAITINGQueue.add(new Object());
	            state = CFQNSDatacenter.WAITING;
	            eventNum++;  // chuyen trang thai va eventnum, event control middle server be canceled
	            // can phai viet them de tat het cac may ON, MIDDLE, SETUP ve OFF
	            // con oFF->MIDDle thi phai xu ly o cac event bat thanh cong bat thanh cong xong thi tat luon
	            //
//	        listHostOff.addAll(listHostON);
//	        listHostON.clear();
	            // bo 2 dong code tren vi may on sau khi hoan thanh xong job ma khong co job thi
	            // tu dong tat

	            // giam so luong MIDDLE di
	            int numberofmiddletokeep = (int) (CFQNSHelper.timeOffToMiddle / timenext);
	            if (listHostMIDDLE.getsize() < numberofmiddletokeep) {

//	            Log.printLine("!!!!!!!!  datacenter ko du server o middle de giam di");
	                // cho nay phai duy tri bat may (ham controlMiddleServer de duy tri bat may bao gio du may middle thi thoi)
//	            state = CFQNSDatacenter.ONMAINTAIN;
	            }
	            while (listHostMIDDLE.getsize() > numberofmiddletokeep) {
	                listHostOff.add(listHostMIDDLE.poll());
	            }
	            turnOffAllHostInSetupMode();

	            // **** can update  mean number of server tai day
	            // update xong thi xoa het nh?ng biet dem number server d
//	        while (!hostOnNumber.isEmpty()) hostOnNumber.poll();
//	        while (!hostSetupNumber.isEmpty()) hostSetupNumber.poll();
	        }
	    }
	  
	public  void calculateTau(){
		//System.out.println("mot");
		//changeLamd
	    int K = NewHelper.jobsqueuecapacity;
		int c = NewHelper.hostNum;
		 double pi[][] = new double[NewHelper.hostNum+1][NewHelper.jobsqueuecapacity+1];
		 double a[][] = new double[NewHelper.hostNum+1][NewHelper.jobsqueuecapacity+1];  
		 double b[][] = new double[NewHelper.hostNum+11][NewHelper.jobsqueuecapacity+1];  
		 double s1[][] = new double[NewHelper.hostNum+1][NewHelper.jobsqueuecapacity+1];
		for(int i = 0; i<= c; i++){
			for(int j = 0;j <= K; j++){
				pi[i][j] = 0;
				a[i][j] = 0;
				b[i][j] =0;
				s1[i][j] =0;
			}
		}
		pi[0][0] = 1;
		int s = c;
		// i = 0
		b[0][K] = (NewHelper.lamda)/(NewHelper.theta*K+s*NewHelper.alpha);
		for(int j  = K-1; j>=1; j--){
				b[0][j] = NewHelper.lamda/(NewHelper.lamda+ min(j, s, c)*NewHelper.alpha
						+j*NewHelper.theta- (j+1)*NewHelper.theta*b[0][j+1]);
		}
		for(int j  = 1; j <= K; j++){
			pi[0][j] =	b[0][j]*pi[0][j-1];
				
		}
		//i =1 	
		for(int j = 1 ; j <= K ; j++){
		// tinh pi[1][1]
			pi[1][1] =pi[1][1]+min(j,c,s)*NewHelper.alpha*pi[0][j]/NewHelper.muy;
		}
		a[1][K] = Math.min(c,s)*NewHelper.alpha*pi[0][K]/(NewHelper.muy+Math.min(c-1, s)*NewHelper.alpha
				+(K-1)*NewHelper.theta);
		b[1][K] =  NewHelper.lamda/(NewHelper.muy+Math.min(c-1, s)*NewHelper.alpha+
				(K-1)*NewHelper.theta);
		for(int j = K-1; j>=2 ; j--){
			a[1][j] =((NewHelper.muy+j*NewHelper.theta)*a[1][j+1]+min(j,c,s)*NewHelper.alpha*
					pi[0][j])/(NewHelper.muy+NewHelper.lamda+min(j-1,c-1,s)*NewHelper.alpha+
							(j-1)*NewHelper.theta-(NewHelper.muy+j*NewHelper.theta)*b[1][j+1]);
			
			b[1][j] = NewHelper.lamda/(NewHelper.muy+NewHelper.lamda+min(j-1,c-1,s)*NewHelper.alpha+
					(j-1)*NewHelper.theta-(NewHelper.muy+j*NewHelper.theta)*b[1][j+1]);
		}
		for(int j = 2 ; j <= K ; j++){
			pi[1][j] = a[1][j]+ b[1][j]*pi[1][j-1];
		}
		// i = 2 den c-1
		for(int i = 2 ; i < c; i++ ){
			for(int j = i; j<= K;j++){
				pi[i][i] = pi[i][i] +( min(j-i+1,c-i+1,s)*NewHelper.alpha*pi[i-1][j])/(NewHelper.muy*i);
			}
			a[i][K] = Math.min(c-i+1, s)*NewHelper.alpha*pi[i-1][K]/(Math.min(c-i, s)*NewHelper.alpha+
					i*NewHelper.muy+(K-i)*NewHelper.theta);
			b[i][K] = NewHelper.lamda/(Math.min(c-i, s)*NewHelper.alpha+
					i*NewHelper.muy+(K-i)*NewHelper.theta);
			
			for(int j = K-1; j >= i+1; j--){
				s1[i][j] = NewHelper.lamda + min(j-i, c-i, s)*NewHelper.alpha+NewHelper.muy*i+
						(j-i)*NewHelper.theta;
				
				a[i][j] =((i*NewHelper.muy+(j-i+1)*NewHelper.theta)*a[i][j+1]+min(j-i+1,c-i+1,s)*NewHelper.alpha*
						pi[i-1][j])/(s1[i][j]-(i*NewHelper.muy+(j+1-i)*NewHelper.theta)*b[i][j+1]);
				b[i][j] = NewHelper.lamda/(s1[i][j]-(i*NewHelper.muy+(j+1-i)*NewHelper.theta)*b[i][j+1]);
				
			}
			for(int j = i+1 ; j<=K; j++){
				pi[i][j] = a[i][j]+b[i][j]*pi[i][j-1];
			}
		}	
	   // i = c
		for(int j = c; j<= K;j++){
			pi[c][c] = (pi[c][c] + min(j-c+1,1,s)*NewHelper.alpha*pi[c-1][j])/(NewHelper.muy*c);
		}
		a[c][K] =	 NewHelper.alpha*pi[c-1][K]/(c*NewHelper.muy+(K-c)*NewHelper.theta);
		b[c][K] = NewHelper.lamda/(c*NewHelper.muy+(K-c)*NewHelper.theta);
		for(int j = K-1; j >= c+1 ; j--){
			a[c][j]=((c*NewHelper.muy+(j+1-c)*NewHelper.theta)*a[c][j+1]+NewHelper.alpha*pi[c-1][j])/
					(NewHelper.lamda+ c*NewHelper.muy+(j-c)*NewHelper.theta-(c*NewHelper.muy
							+(j-c+1)*NewHelper.theta)*b[c][j+1]	);
			b[c][j] = NewHelper.lamda/(NewHelper.lamda+ c*NewHelper.muy+(j-c)*NewHelper.theta-(c*NewHelper.muy
					+(j-c+1)*NewHelper.theta)*b[c][j+1]);
			
			
					
		}
		for(int j= c+1;j <= K ; j++){
			pi[c][j] = a[c][j]+pi[c][j-1]*b[c][j];
		}
		
		// tinh To
		double  temp = 0;
		for(int i  = 0; i <= c; i++ ){
			for(int j = i; j <= K; j++){
				temp = temp + pi[i][j];
				
			}
			//System.out.println("temp  ="+temp);
		}
		
		
		// tinh pi[0][0]
		pi[0][0] = 1/temp;
		double temp2 = pi[0][0];
		//System.out.println("temp = "+temp);
		
		for(int i = 0; i<= c; i++){
			for(int j = i;j <= K; j++){
				if(j!=0) pi[i][j] =  pi[i][j]*temp2;
			}
		}
		temp2 = 0;
		for(int i = 0; i <= c; i++)
			for(int j = i+1; j<= K ; j++)
				temp2 = temp2 + pi[i][j]*min(c-i,j-i,s);
		timenext =  1/(NewHelper.alpha*temp2);
		
    	
    }
    public static int min(int a, int b ,int c){
		int min =a;
		if(b < min) min = b;
		if(c < min) min = c;
		return min;
	}
	

}
